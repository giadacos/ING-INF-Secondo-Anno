package poo.pn;
import java.util.LinkedList;
import java.util.List;

public class Transizione extends Entita{
	private List<ArcoIn> preset;
	private List<ArcoOut> postset;
	public Transizione( String nome, List<ArcoIn> preset, List<ArcoOut> postset ) {
		super(nome);
		this.preset=preset;
		this.postset=postset;
	}
	
	public boolean abilitata() {
		for( ArcoIn ai: preset )
			if( !ai.abilitato() ) return false;
		return true;
	}//abilitata
	
	public void sparo() {
		if( !abilitata() ) 
			throw new RuntimeException("Tentativo di sparo di transizione disabilitata!");
		//withdraw
		for( ArcoIn ai: preset ) {
			Posto p=ai.getPosto();
			p.setMarcatura( p.getMarcatura()-ai.getPeso() );
		}
		//deposit
		for( ArcoOut au: postset ) {
			Posto p=au.getPosto();
			p.setMarcatura( p.getMarcatura()+au.getPeso() );
		}				
	}//sparo
	
	public String toString() {
		String s=super.toString()+" preset=";
		for( ArcoIn ai: preset )
			s=s+ai.getPosto().getNome()+" peso#"+ai.getPeso()+" ";
		s=s+" postset=";
		for( ArcoOut au: postset )
			s=s+au.getPosto().getNome()+" peso#"+au.getPeso()+" ";
		s=s+"\n";
	    return s;			
	}
}//Transizione


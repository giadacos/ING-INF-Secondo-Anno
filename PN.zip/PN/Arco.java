package poo.pn;

public abstract class Arco {
	private Posto p;
	private int peso;
	public Arco( Posto p, int peso ) {
		if( peso<0 ) throw new IllegalArgumentException();
		this.p=p; this.peso=peso;
	}
	public Arco( Posto p ) {
		this(p,1);
	}
	Posto getPosto() {
		return p;
	}
	public int getPeso() {
		return peso;
	}
	public String toString() {
		return "Arco peso:"+peso;
	}
}//Arco

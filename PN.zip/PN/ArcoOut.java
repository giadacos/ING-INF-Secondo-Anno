package poo.pn;

public class ArcoOut extends Arco{
	public ArcoOut( Posto p, int peso ) {
		super(p,peso);
	}
	public ArcoOut( Posto p ) {
		this(p,1);
	}
	public String toString() {
		return super.toString()+" di uscita";
	}	
}//ArcoOut

package poo.pn;

public abstract class Entita {
	private String nome;
	public Entita( String nome ) {
		this.nome=nome;
	}
	public String getNome() { return nome; }
	public String toString() {
		return nome;
	}
	public boolean equals( Object o ) {
		if( !(o instanceof Entita) ) return false;
		if( o==this ) return true;
		Entita e=(Entita)o;
		return this.nome.equals(e.nome);
	}
	public int hashCode() { return nome.hashCode(); }
}//Entita


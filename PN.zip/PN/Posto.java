package poo.pn;

public class Posto extends Entita{
	private int marcatura;
	public Posto( String nome, int marcatura ) {
		super(nome);
		if( marcatura<0 ) throw new IllegalArgumentException();
		this.marcatura=marcatura;
	}
	public Posto( String nome ) {
		this(nome,0);
	}
	public Posto( Posto p ) {
		this( p.getNome(), p.marcatura );
	}
	public int getMarcatura() { return marcatura; }
	public void setMarcatura( int marcatura ) {
		if( marcatura<0 ) throw new IllegalArgumentException();
		this.marcatura=marcatura;
	}
	public String toString() {
		return super.toString()+"#"+marcatura;
	}
}//Posto

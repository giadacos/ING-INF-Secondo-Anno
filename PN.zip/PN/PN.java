package poo.pn;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class PN {
	
	private Map<String,Posto> M;
	private LinkedList<Transizione> abilitate=new LinkedList<>();
	private LinkedList<Transizione> disabilitate=new LinkedList<>();
	
	public PN( Map<String,Posto> M, LinkedList<Transizione> T ) {
		this.M=M;
		for( Transizione t: T )
			if( t.abilitata() ) abilitate.add(t);
			else disabilitate.add(t);
	}
	
	public void singleStep() {
		if( abilitate.isEmpty() ) {
			System.out.println("Deadlock!"); 
			return; 
		}
		
		Collections.shuffle(abilitate);
		Iterator<Transizione> itc=abilitate.iterator();
		Transizione t=itc.next(); itc.remove(); 
		disabilitate.add(t); //pessimismo
		
		t.sparo();

		//individuazione transizioni disabilitate a causa di t
		while( itc.hasNext() ) {
			Transizione q=itc.next();
			if( !q.abilitata() ) { 
				disabilitate.add(q); 
				itc.remove(); 
			}
		}
		
		//individuazione transizioni che si abilitano a causa di t
		Iterator<Transizione> itd=disabilitate.iterator();
		while( itd.hasNext() ) {
			Transizione q=itd.next();
			if( q.abilitata() ) { itd.remove(); abilitate.add(q); }
		}
		
		System.out.println("Marcatura dopo lo sparo di "+t.getNome());
		for( String s: M.keySet() )
			System.out.print(M.get(s)+" ");
		System.out.println();
		
	}//singleStep
	
	public void multipleSteps( int s ) {
		if( s<0 ) throw new IllegalArgumentException();
		for( int i=0; i<s; ++i ) {
			if( abilitate.isEmpty() ) {
				System.out.println("Deadlock!"); 
				return; 
			}
			singleStep();
		}
	}//multipleSteps
	
}//PN

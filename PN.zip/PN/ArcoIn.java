package poo.pn;

public class ArcoIn extends Arco{
	public ArcoIn( Posto p, int peso ) {
		super(p,peso);
	}
	public ArcoIn( Posto p ) {
		this(p,1);
	}
	public String toString() {
		return super.toString()+" di ingresso";
	}
	public boolean abilitato() {
		return getPosto().getMarcatura()>=getPeso();
	}
}//ArcoIn

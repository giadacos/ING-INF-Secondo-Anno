package poo.pn;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.*;

public class Main {
	public static void main( String[] args ) {
		
		Posto p1=new Posto("p1",2), p2=new Posto("p2"), 
			  p3=new Posto("p3"), p4=new Posto("p4");
		
		Map<String,Posto> M=new HashMap<>();
		M.put("p1",p1); M.put("p2",p2); M.put("p3",p3); M.put("p4",p4);
		
		Transizione t1=new Transizione("t1", 
				Arrays.asList(new ArcoIn(p1)),
				Arrays.asList(new ArcoOut(p2)) );	
		Transizione t2=new Transizione("t2", 
				Arrays.asList(new ArcoIn(p2)),
				Arrays.asList(new ArcoOut(p3)) );
		Transizione t3=new Transizione("t3", 
				Arrays.asList(new ArcoIn(p2)),
				Arrays.asList(new ArcoOut(p4)) );
		Transizione t4=new Transizione("t4", 
				Arrays.asList(new ArcoIn(p3),new ArcoIn(p4)),
				Arrays.asList(new ArcoOut(p1)) );
		Transizione t5=new Transizione("t5", 
				Arrays.asList(new ArcoIn(p4)),
				Arrays.asList(new ArcoOut(p1)) );
		LinkedList<Transizione> T=
				new LinkedList<>( java.util.Arrays.asList(t1,t2,t3,t4,t5) );
		
		System.out.println("Marcatura iniziale:");
		for( String s: M.keySet() )
			System.out.print(M.get(s)+" ");
		System.out.println();

		PN pn=new PN(M,T);
		pn.multipleSteps(5);
		
	}//main
}//Main
